class ResumeTailorEngine:

    def analyze_job_fit(
        self,
        profile,
        job
    ):

        profile_skills = [

            str(skill).lower()

            for skill in profile.get(
                "skills",
                []
            )

        ]

        text = (

            job.get(
                "description",
                ""
            )

            + " "

            + job.get(
                "role",
                job.get(
                    "title",
                    ""
                )
            )

        ).lower()

        matched = []
        missing = []

        for skill in profile_skills:

            if skill in text:

                matched.append(skill)

            else:

                missing.append(skill)

        total = len(profile_skills)

        score = round(

            (

                len(matched)
                /
                total

            ) * 100,

            2

        ) if total else 0

        recommendations = []

        if missing:

            recommendations.append(

                "Include these relevant keywords where they genuinely match your experience: "

                + ", ".join(missing[:15])

            )

        recommendations.append(

            "Quantify achievements using revenue, growth %, cost savings, customer acquisition, project value and team size."

        )

        recommendations.append(

            "Mirror the wording used in the job description."

        )

        recommendations.append(

            "Customize the Executive Summary for this specific role."

        )

        return {

            "match_score": score,

            "matched_skills": sorted(matched),

            "missing_skills": sorted(missing),

            "recommendations": recommendations

        }

    # --------------------------------------------------

    def generate_executive_summary(
        self,
        profile,
        job
    ):

        role = job.get(

            "role",

            job.get(

                "title",

                "Executive Role"

            )

        )

        experience = profile.get(

            "experience",

            "20+"

        )

        industry = profile.get(

            "industry",

            "Technology"

        )

        return (

            f"Executive leader with {experience} years of experience delivering revenue growth, "
            f"commercial excellence, operational transformation, customer success and strategic leadership "
            f"across {industry}. Proven ability to build high-performing teams, manage P&L, drive enterprise "
            f"growth and deliver measurable business outcomes. Well aligned for the {role} opportunity."

        )