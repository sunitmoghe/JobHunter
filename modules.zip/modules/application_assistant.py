class ApplicationAssistant:

    # --------------------------------------------------
    # COMPLETE AI PACKAGE
    # --------------------------------------------------

    def generate(
        self,
        profile,
        job
    ):

        return {

            "linkedin_message": self.generate_linkedin_message(
                profile,
                job
            ),

            "cover_letter": self.generate_cover_letter(
                profile,
                job
            ),

            "recruiter_email": self.generate_recruiter_email(
                profile,
                job
            ),

            "follow_up": self.generate_followup_email(
                profile,
                job
            ),

            "thank_you": self.generate_thank_you_email(
                profile,
                job
            )

        }

    # --------------------------------------------------

    def generate_linkedin_message(
        self,
        profile,
        job
    ):

        return f"""
Hello,

I came across the {job.get('role','Executive Position')} opportunity at {job.get('company','your organisation')}.

With 23+ years of executive leadership across Sales, Operations, Customer Success and Business Transformation, I believe my experience aligns well with your leadership requirements.

I'd appreciate the opportunity to connect and learn more.

Regards,

{profile.get('name','')}
"""

    # --------------------------------------------------

    def generate_cover_letter(
        self,
        profile,
        job
    ):

        return f"""
Dear Hiring Manager,

I am excited to apply for the position of {job.get('role','Executive')}.

Over the last 23+ years I have successfully delivered:

• Revenue Growth
• P&L Ownership
• Executive Leadership
• International Business Expansion
• Customer Success
• Strategic Partnerships
• Sales Transformation

I would welcome the opportunity to discuss how my experience can contribute to {job.get('company','your organisation')}.

Kind Regards,

{profile.get('name','')}
"""

    # --------------------------------------------------

    def generate_recruiter_email(
        self,
        profile,
        job
    ):

        return f"""
Subject: Application for {job.get('role','Executive Position')}

Dear Recruiter,

I recently applied for the {job.get('role','Executive Position')} opportunity.

With more than 23 years of executive leadership experience, I believe my background closely aligns with your requirements.

I would appreciate the opportunity to discuss my candidature.

Regards,

{profile.get('name','')}
"""

    # --------------------------------------------------

    def generate_followup_email(
        self,
        profile,
        job
    ):

        return f"""
Dear Hiring Team,

I wanted to follow up regarding my application for the {job.get('role','Executive Position')} position.

I remain very interested in the opportunity and would welcome the chance to discuss how I can contribute to your organisation.

Thank you for your time.

Regards,

{profile.get('name','')}
"""

    # --------------------------------------------------

    def generate_thank_you_email(
        self,
        profile,
        job
    ):

        return f"""
Dear Interview Panel,

Thank you for taking the time to meet with me regarding the {job.get('role','Executive Position')} opportunity.

I enjoyed our discussion and remain enthusiastic about joining your leadership team.

I appreciate your consideration.

Regards,

{profile.get('name','')}
"""

    # --------------------------------------------------

    def generate_interview_questions(
        self,
        job
    ):

        return [

            "Describe your biggest executive achievement.",

            "How have you driven revenue growth?",

            "Describe a business turnaround you led.",

            "Explain your leadership philosophy.",

            "Describe your P&L ownership.",

            "How do you build executive teams?",

            "Describe strategic partnerships you developed.",

            "How do you manage large customers?",

            "Describe a difficult board-level decision.",

            "Why should we hire you?"

        ]

    # --------------------------------------------------

    def executive_application_checklist(self):

        return [

            "Resume tailored",

            "ATS optimized",

            "Executive cover letter",

            "LinkedIn message",

            "Recruiter email",

            "Company research",

            "Leadership stories",

            "Financial research",

            "Interview preparation",

            "Follow-up completed"

        ]

    # --------------------------------------------------

    def interview_tips(self):

        return [

            "Quantify achievements.",

            "Think strategically.",

            "Focus on leadership.",

            "Demonstrate business impact.",

            "Speak commercially.",

            "Use STAR examples."

        ]